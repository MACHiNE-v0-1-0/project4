
</div> <!-- /wrapper -->

	<hr class="green-horizon black-border"/>
<div id="#footer">
	
	(C)Footer
</div>


	<?php  $this->loadDefaultJs(); ?>

</body>
</html>