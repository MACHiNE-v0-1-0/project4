$('document').ready(function(){
	var body = $('body');

	



});