	// always add trailing slash after URL
const DOMAIN = "http://localhost/project4/";
