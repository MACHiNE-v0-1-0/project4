console.log('cart check-out');
$('document').ready(function(){
	var btnCheckOut = $('.cart-check-out button');
	btnCheckOut.click(function(){
		$.ajax({
			url: DOMAIN +"LoadHtml/loadCartCheckOut", 
			dataType:'html',
			error:function(err, status){
				console.log(status);
			},
			success:function(res){
				if($('#cart-check-out-modal').length === 0){
					$('body').prepend(res);
				} else {
					$('#cart-check-out-modal').css('display', 'block');
				}
				/*
					Close modal when clicked on close btn
				*/
					var btnCloseCheckOut = $('.check-out-btn-close button');
					btnCloseCheckOut.click(function(){
						$('#cart-check-out-modal').css('display', 'none');

					});
				

				
			} // end success
		}); // end ajax
	});



			

	
});