<?php
namespace App\Helpers\Traits;

trait Test 
{
	public function show()
	{
		echo "<br>showing off";
	}
}