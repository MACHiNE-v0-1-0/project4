<?php
namespace App\Helpers\Interfaces;

interface TestInterface {
	public function test();
}