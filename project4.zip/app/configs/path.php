<?php
define('DOMAIN', "http://localhost/project4/");

define("ROOT", $_SERVER['DOCUMENT_ROOT'].'/project4/');