
<center>
	<h1>Register</h1>
	<p>(*) fields must be filled</p>
	<form action="<?= DOMAIN."Register/submitRegister" ?> " method="POST" id="reg-form">
		<table>
			<tr>
				<td>Username(*):</td>
				<td><input type="text" name="reg-username" id="reg-username"></td>
			</tr>
			<tr>
				<td></td>
				<td id="err-reg-username"  class='err-reg'></td>
			</tr>
			<tr>
				<td>Password(*):</td>
				<td><input type="password" name="reg-password" id="reg-password"></td>
			</tr>
			<tr>
				<td></td>
				<td id="err-reg-password" class='err-reg'></td>
			</tr>
			<tr>
				<td>Re-Password(*):</td>
				<td><input type="password" name="reg-repassword" id="reg-repassword"></td>
			</tr>
			<tr>
				<td></td>
				<td id="err-reg-repassword" class='err-reg'></td>
			</tr>
			<tr>
				<td>Email(*):</td>
				<td><input type="email" name="reg-email" id="reg-email"></td>
			</tr>
			<tr>
				<td></td>
				<td id="err-reg-email" class='err-reg'></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" name="reg-submit" id="reg-submit"></td>
			</tr>
		</table>
	</form>

</center>