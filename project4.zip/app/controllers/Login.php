<?php
namespace App\Controllers;
	
use App\Libs\BaseController;
use App\Libs\Session;
use App\Libs\Authenticate;

class Login extends BaseController{
	public function __construct(){
		parent::__construct();
	}

	public function index(){
		if(Authenticate::isLogin()){
			header("Location:". DOMAIN);
		}
		$this->view->render("Login/login-form");
	}

	public function submitLogin(){
		// check if user has put blank username or password and submited the form.
		if($this->errBlankLogin()){ 
			//header("Location:". DOMAIN);
			echo "blank login";
		} 
		
		$username = $_POST["login-username"];
		$password = $_POST["login-password"];



		if($this->model->loginProceed($username, $password)){
			echo "true login";
			//header("Location:http://localhost/project4/");
			header("Location:". DOMAIN);

		} else {
			echo "false login";
			$this->view->render("Login/login-form");
		}
	}
	
	public function ajaxSubmit(){
		
		if($this->submitLogin()){
			echo "true";
		} else {
			echo "false";
		}

	}

	public function errBlankLogin(){
		$username = $_POST["login-username"];
		$password = $_POST["login-password"];

		if(empty($username) || empty($password)) {
			return true;
		} else {
			return false;
		}
	}
}