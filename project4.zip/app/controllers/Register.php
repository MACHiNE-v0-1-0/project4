<?php
namespace App\Controllers;

use App\Libs\BaseController;

class Register extends BaseController{
	public function __construct(){
		parent::__construct();
	}

	public function index(){
		$this->view->render("Register/register-form");
	}

	public function submitRegister(){
		$err = array();
		echo "submit register";
	}
}