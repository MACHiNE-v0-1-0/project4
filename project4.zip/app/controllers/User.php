<?php
namespace App\Controllers;

use App\Libs\BaseController;
use App\Libs\Authenticate;

class User extends BaseController {
	public function __construct(){
		parent::__construct();
	}

	public function isLogin(){
		if(Authenticate::isLogin()){
			echo 'logged in';
			return true;
		} else {
			echo  'false';
			return false;
		}
	}

}