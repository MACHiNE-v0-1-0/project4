<?php
namespace App\Controllers;

use App\Libs\BaseController;
use App\Libs\Authenticate;
use App\Libs\Session;

class Logout extends BaseController{
	
	public function __construct(){
		parent::__construct();
	}

	public function index(){
		if(Authenticate::isLogin()){
			$flagLogout = Session::del('user');
			if(!$flagLogout) {
				echo "logout has something wrong, go check it out";
			}
		// when user logout
			// we should save cart data of user into database
			unset($_SESSION['cart']);

			header("Location:".DOMAIN);
		} else {
			echo "<br> logout failed";
			
		}
	}
}