<?php 

namespace App\Controllers;

use App\Libs\BaseController;

class LoadHtml extends BaseController {
	public function __construct(){
		parent::__construct();
	}

	public function loadCartCheckOut() {
		include_once ROOT . 'app/Views/assets/cart-check-out.php';
		
	}

}