<?php 
namespace App\Libs;

use App\Libs\Session;

class Authenticate {
	public static function isLogin(){
		if(Session::peek("user")) {
			return true;
		} else {
			return false;
		}
	}

	public static function isAdmin() {

		if(!Authenticate::isLogin()) {
			echo "<br>you must login before checking you are admin or not";
			return false;
		}
		
		if(Session::get('user')['level'] === 'admin'){
			return true;
		} else {
			return false;
		}
	}
}