<?php
namespace App\Models;

use App\Libs\BaseModel;

class LogoutModel extends BaseModel{
	public function __construct(){}
}