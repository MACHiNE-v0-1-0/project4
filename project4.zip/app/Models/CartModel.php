<?php
namespace App\Models;

use App\Libs\BaseModel;
use App\Libs\Session;

class CartModel extends BaseModel{
	public function __construct(){
		parent::__construct();
	}

	public function getCart($cart){
		$data = array();
		$query = "SELECT `product_id`,`name`,`avatar`,`price`,`rateSale`
				  FROM `products`
				  WHERE `product_id` = :num";

		$stmt = $this->db->prepare($query);
		
		foreach ($cart as $product) {
			
			try {
				$stmt->bindValue(":num", $product['id']);
				if($stmt->execute()){
					$result = $stmt->fetch(\PDO::FETCH_ASSOC);
					
					if($result === false) {
						echo "can't get any product";
						return false;
					}
				// bind the quantity 
					$result['quantity'] = $product['quantity'];
											
				// calculate the price after sale rate 
									
					if($result['rateSale'] !== null && $result['rateSale'] !== 0 ){
						$tienPhaiTru = ($result['price'] * $result['rateSale']) / 100;
						$result['price2'] = $result['price'] - $tienPhaiTru;
					}  else {
						$result['price2'] = $result['price'];
					}
				// check if product has avatar or not//
					if($result['avatar'] === null ){
						$result['avatar'] = 'no-img.png';
					}
					$data[] = $result;
				} else {
					throw new PDOException('Can\'t execute query');
					return false;				
				}
			} catch(PDOException $err){
				echo $err->getMessage();
			}
		}

		return $data;
	}

// 
	public function checkOutProcess(array $req){
		
	}
}